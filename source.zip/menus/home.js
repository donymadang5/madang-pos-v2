const productService = require("../services/productService");
const sessionService = require("../services/sessionService");
const customerService = require("../services/customerService");
const { sendButtons } = require("../utils/ui");

module.exports = async (sock, jid) => {

    // Pastikan data customer ada
    await customerService.saveCustomer(jid);

    // Cek registrasi
    const registered = await customerService.isRegistered(jid);

    if (!registered) {

        await sessionService.goto(jid, "REGISTER_NAME");

        return sock.sendMessage(jid, {
            text:
`👋 *Selamat datang di MADANG VAPE*

Sebelum mulai berbelanja, silakan registrasi terlebih dahulu.

📝 Silakan masukkan *nama lengkap* Anda.

Contoh:
Dony Saputra`
        });

    }

    const kategori = await productService.getCategories();

    await sessionService.goto(jid, "HOME", {
        type: "CUSTOMER",
        page: "HOME",
        kategori
    });

    await sendButtons(
        sock,
        jid,
`👋 Selamat datang di *Madang POS*

Silakan pilih menu di bawah ini.

Atau balas angka:

1️⃣ Belanja
2️⃣ Pesanan Saya
3️⃣ Bantuan
0️⃣ Keluar`,
        "🏪 Madang POS",
        [
            {
                buttonId: "MENU_BELANJA",
                buttonText: {
                    displayText: "🛒 Belanja"
                },
                type: 1
            },
            {
                buttonId: "MENU_PESANAN",
                buttonText: {
                    displayText: "📦 Pesanan Saya"
                },
                type: 1
            },
            {
                buttonId: "MENU_ADMIN",
                buttonText: {
                    displayText: "☎ Bantuan"
                },
                type: 1
            }
        ]
    );

};
